## Configuration

- OpenAI API Key: `openai_api_key`
- WhatsApp Token: `whatsapp_token`
- Default Language: `default_lang`

Use the settings page under the AI Suite admin menu. Values are stored in `perfex_ai_settings`.
