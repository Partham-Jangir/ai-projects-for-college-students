document.addEventListener('DOMContentLoaded',function(){})
