INSERT INTO perfex_ai_settings (name, value, updated_at) VALUES ('default_lang','english',NOW());
INSERT INTO perfex_ai_templates (type, name, body, lang, created_at, updated_at) VALUES ('whatsapp','welcome','Welcome to Perfex AI Suite','english',NOW(),NOW());
